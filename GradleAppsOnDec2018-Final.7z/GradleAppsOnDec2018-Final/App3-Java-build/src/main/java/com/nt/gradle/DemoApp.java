package com.nt.gradle;

public class DemoApp{
       public int sum(int x,int y){
                return x+y;
         }
   public static void main(String args[]){
       System.out.println("DemoApp-->main(-)");
         DemoApp obj=null;
          obj=new DemoApp();
          System.out.println(obj.sum(10,20));
     }
 }
  
