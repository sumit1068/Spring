package com.nt.gradle;

public class DemoApp{
       public int sum(int x,int y){
                return x+y;
         }
 }
  
