package com.nt.gradle;

public class DemoApp{
       public int sum(int x,int y){
                return x+y;
         }
   public  static void main(String args[]){
         DemoApp app=new DemoApp();
      System.out.println("result::"+app.sum(10,20));
   }
 }
  
