package com.nt.test;

import org.junit.*;
import static  org.junit.Assert.*;
import  com.nt.gradle.DemoApp;

public class AppTest{

@Test
 public  void   testSumWithPositives(){
     int expected=50;
     int actual=new DemoApp().sum(10,20);
    assertEquals("test1",actual,expected);
  }

@Test
 public  void   testSumWithNegetives(){
     int expected=-30;
     int actual=new DemoApp().sum(-10,-20);
    assertEquals("test2",actual,expected);
  }

@Test
@Ignore
 public  void   testSumWithPositivesAndNegetives(){
     int expected=-10;
     int actual=new DemoApp().sum(10,-20);
    assertEquals("test3",actual,expected);
  }

@Test
 public  void   testSumWithZeros(){
     int expected=0;
     int actual=new DemoApp().sum(0,0);
    assertEquals("test4",actual,expected);
  }



}