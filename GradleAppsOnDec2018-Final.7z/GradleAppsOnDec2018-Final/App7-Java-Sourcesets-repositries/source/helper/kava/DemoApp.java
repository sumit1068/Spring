package com.nt.gradle;

public class DemoApp{
       public int sum(int x,int y){
                return x+y;
         }
   public  static void main(String args[])throws Exception{
         DemoApp app=new DemoApp();
      System.out.println("result::"+app.sum(10,20));
        Class.forName("oracle.jdbc.driver.OracleDriver");
         System.out.println("Oracle driver is loaded");
   }
 }
  
