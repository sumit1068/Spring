package com.nt.servlet;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.*;

@WebServlet("/formurl")
public class FormServlet extends HttpServlet{

   public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
     PrintWriter pw=null;
    pw=res.getWriter();
    res.setContentType("text/html");
    pw.println("<h1 style='color:red'> Mr/Miss/Mrs. "+ req.getParameter("t1")+"</h1>");
    pw.println("<br><a href='form.html'>go </a>");
    pw.close();
  }
   public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
          doGet(req,res);
     }
}
