@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.atm.com/")
package com.nt.bindings;
