
package com.ws.bindings;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ws.bindings package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GreetResource_QNAME = new QName("http://services.nit.com/", "greetResource");
    private final static QName _GreetResourceResponse_QNAME = new QName("http://services.nit.com/", "greetResourceResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ws.bindings
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GreetResource }
     * 
     */
    public GreetResource createGreetResource() {
        return new GreetResource();
    }

    /**
     * Create an instance of {@link GreetResourceResponse }
     * 
     */
    public GreetResourceResponse createGreetResourceResponse() {
        return new GreetResourceResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GreetResource }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.nit.com/", name = "greetResource")
    public JAXBElement<GreetResource> createGreetResource(GreetResource value) {
        return new JAXBElement<GreetResource>(_GreetResource_QNAME, GreetResource.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GreetResourceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.nit.com/", name = "greetResourceResponse")
    public JAXBElement<GreetResourceResponse> createGreetResourceResponse(GreetResourceResponse value) {
        return new JAXBElement<GreetResourceResponse>(_GreetResourceResponse_QNAME, GreetResourceResponse.class, null, value);
    }

}
