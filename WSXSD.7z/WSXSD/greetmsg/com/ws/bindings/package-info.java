@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.nit.com/")
package com.ws.bindings;
