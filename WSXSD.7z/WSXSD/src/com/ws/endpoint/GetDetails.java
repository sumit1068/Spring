
package com.ws.endpoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="from" type="{http://endpoint.ws.com/}TrainType" minOccurs="0"/>
 *         &lt;element name="to" type="{http://endpoint.ws.com/}TrainType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getDetails", propOrder = {
    "from",
    "to"
})
public class GetDetails {

    protected TrainType from;
    protected TrainType to;

    /**
     * Gets the value of the from property.
     * 
     * @return
     *     possible object is
     *     {@link TrainType }
     *     
     */
    public TrainType getFrom() {
        return from;
    }

    /**
     * Sets the value of the from property.
     * 
     * @param value
     *     allowed object is
     *     {@link TrainType }
     *     
     */
    public void setFrom(TrainType value) {
        this.from = value;
    }

    /**
     * Gets the value of the to property.
     * 
     * @return
     *     possible object is
     *     {@link TrainType }
     *     
     */
    public TrainType getTo() {
        return to;
    }

    /**
     * Sets the value of the to property.
     * 
     * @param value
     *     allowed object is
     *     {@link TrainType }
     *     
     */
    public void setTo(TrainType value) {
        this.to = value;
    }

}
