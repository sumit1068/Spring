@javax.xml.bind.annotation.XmlSchema(namespace = "http://endpoint.ws.com/")
package com.ws.endpoint;
