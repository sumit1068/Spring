
package com.nt.bindings;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getStudentCourseDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getStudentCourseDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="stu" type="{http://endpoint.ws.nt.com/}Students" minOccurs="0"/>
 *         &lt;element name="cu" type="{http://endpoint.ws.nt.com/}Course" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getStudentCourseDetails", propOrder = {
    "stu",
    "cu"
})
public class GetStudentCourseDetails {

    protected Students stu;
    protected Course cu;

    /**
     * Gets the value of the stu property.
     * 
     * @return
     *     possible object is
     *     {@link Students }
     *     
     */
    public Students getStu() {
        return stu;
    }

    /**
     * Sets the value of the stu property.
     * 
     * @param value
     *     allowed object is
     *     {@link Students }
     *     
     */
    public void setStu(Students value) {
        this.stu = value;
    }

    /**
     * Gets the value of the cu property.
     * 
     * @return
     *     possible object is
     *     {@link Course }
     *     
     */
    public Course getCu() {
        return cu;
    }

    /**
     * Sets the value of the cu property.
     * 
     * @param value
     *     allowed object is
     *     {@link Course }
     *     
     */
    public void setCu(Course value) {
        this.cu = value;
    }

}
