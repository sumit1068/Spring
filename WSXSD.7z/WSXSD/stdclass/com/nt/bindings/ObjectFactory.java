
package com.nt.bindings;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.nt.bindings package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetStudentCourseDetails_QNAME = new QName("http://endpoint.ws.nt.com/", "getStudentCourseDetails");
    private final static QName _CourseType_QNAME = new QName("http://endpoint.ws.nt.com/", "CourseType");
    private final static QName _GetStudentCourseDetailsResponse_QNAME = new QName("http://endpoint.ws.nt.com/", "getStudentCourseDetailsResponse");
    private final static QName _StudentsType_QNAME = new QName("http://endpoint.ws.nt.com/", "StudentsType");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.nt.bindings
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Students }
     * 
     */
    public Students createStudents() {
        return new Students();
    }

    /**
     * Create an instance of {@link GetStudentCourseDetailsResponse }
     * 
     */
    public GetStudentCourseDetailsResponse createGetStudentCourseDetailsResponse() {
        return new GetStudentCourseDetailsResponse();
    }

    /**
     * Create an instance of {@link Course }
     * 
     */
    public Course createCourse() {
        return new Course();
    }

    /**
     * Create an instance of {@link GetStudentCourseDetails }
     * 
     */
    public GetStudentCourseDetails createGetStudentCourseDetails() {
        return new GetStudentCourseDetails();
    }

    /**
     * Create an instance of {@link StudentCourseType }
     * 
     */
    public StudentCourseType createStudentCourseType() {
        return new StudentCourseType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStudentCourseDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.ws.nt.com/", name = "getStudentCourseDetails")
    public JAXBElement<GetStudentCourseDetails> createGetStudentCourseDetails(GetStudentCourseDetails value) {
        return new JAXBElement<GetStudentCourseDetails>(_GetStudentCourseDetails_QNAME, GetStudentCourseDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Course }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.ws.nt.com/", name = "CourseType")
    public JAXBElement<Course> createCourseType(Course value) {
        return new JAXBElement<Course>(_CourseType_QNAME, Course.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStudentCourseDetailsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.ws.nt.com/", name = "getStudentCourseDetailsResponse")
    public JAXBElement<GetStudentCourseDetailsResponse> createGetStudentCourseDetailsResponse(GetStudentCourseDetailsResponse value) {
        return new JAXBElement<GetStudentCourseDetailsResponse>(_GetStudentCourseDetailsResponse_QNAME, GetStudentCourseDetailsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Students }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.ws.nt.com/", name = "StudentsType")
    public JAXBElement<Students> createStudentsType(Students value) {
        return new JAXBElement<Students>(_StudentsType_QNAME, Students.class, null, value);
    }

}
