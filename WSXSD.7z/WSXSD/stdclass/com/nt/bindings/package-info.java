@javax.xml.bind.annotation.XmlSchema(namespace = "http://endpoint.ws.nt.com/")
package com.nt.bindings;
